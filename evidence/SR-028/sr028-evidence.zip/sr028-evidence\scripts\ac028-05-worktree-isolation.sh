set -euo pipefail
ROOT="$(pwd -P)"
test -f "$ROOT/pyproject.toml"
if [ -n "${SR028_EVIDENCE_DIR:-}" ]; then
  EVIDENCE_DIR="$SR028_EVIDENCE_DIR"
  test ! -e "$EVIDENCE_DIR"
  mkdir -p "$EVIDENCE_DIR"
else
  EVIDENCE_DIR="$(mktemp -d "${TMPDIR:-/tmp}/sr028-ab-a-evidence.XXXXXX")"
fi
EVIDENCE_DIR="$(cd "$EVIDENCE_DIR" && pwd -P)"
case "$EVIDENCE_DIR/" in "$ROOT/"*) echo 'Evidence directory must be outside the repository' >&2; exit 2 ;; esac
WORKTREE_PARENT="$(mktemp -d "${TMPDIR:-/tmp}/sr028-ab-a-worktrees.XXXXXX")"
A_PATH="$WORKTREE_PARENT/a"
B_PATH="$WORKTREE_PARENT/b"
A_ADDED=0
B_ADDED=0
cleanup() {
  local original_rc=$?
  local cleanup_rc=0
  local cmd_rc=0
  trap - EXIT
  set +e
  cd "$ROOT"
  cmd_rc=$?
  if [ "$cmd_rc" -ne 0 ] && [ "$cleanup_rc" -eq 0 ]; then cleanup_rc=$cmd_rc; fi
  if [ "$B_ADDED" -eq 1 ]; then
    git -C "$ROOT" worktree remove --force "$B_PATH"
    cmd_rc=$?
    if [ "$cmd_rc" -ne 0 ] && [ "$cleanup_rc" -eq 0 ]; then cleanup_rc=$cmd_rc; fi
  fi
  if [ "$A_ADDED" -eq 1 ]; then
    git -C "$ROOT" worktree remove --force "$A_PATH"
    cmd_rc=$?
    if [ "$cmd_rc" -ne 0 ] && [ "$cleanup_rc" -eq 0 ]; then cleanup_rc=$cmd_rc; fi
  fi
  rmdir "$WORKTREE_PARENT"
  cmd_rc=$?
  if [ "$cmd_rc" -ne 0 ] && [ "$cleanup_rc" -eq 0 ]; then cleanup_rc=$cmd_rc; fi
  printf 'SR028_EVIDENCE_DIR=%s\n' "$EVIDENCE_DIR"
  if [ "$original_rc" -ne 0 ]; then exit "$original_rc"; fi
  if [ "$cleanup_rc" -ne 0 ]; then exit "$cleanup_rc"; fi
}
trap cleanup EXIT
git worktree add --detach "$A_PATH" HEAD
A_ADDED=1
git worktree add --detach "$B_PATH" HEAD
B_ADDED=1

capture_env() {
  local label="$1"
  local worktree="$2"
  (
    cd "$worktree"
    uv run --no-sync --locked --group dev --extra plugins python - "$worktree" "$EVIDENCE_DIR/$label.json" "$EVIDENCE_DIR/$label.direct_url.json" <<'PY'
import importlib.metadata as metadata
import json
import os
import pathlib
import sys
import urllib.parse
import urllib.request
import ca_agent_next
root = pathlib.Path(sys.argv[1]).resolve()
report_path = pathlib.Path(sys.argv[2])
direct_url_path = pathlib.Path(sys.argv[3])
raw = metadata.distribution("ca-agent-next").read_text("direct_url.json")
assert raw is not None, "direct_url.json is missing"
direct = json.loads(raw)
url = direct["url"]
parsed = urllib.parse.urlparse(url)
assert parsed.scheme == "file", url
source = pathlib.Path(urllib.request.url2pathname(parsed.path)).resolve()
venv = (root / ".venv").resolve()
sys_prefix = pathlib.Path(sys.prefix).resolve()
executable = pathlib.Path(os.path.abspath(sys.executable))
module = pathlib.Path(ca_agent_next.__file__).resolve()
editable = direct.get("dir_info", {}).get("editable") is True
assert (venv / "pyvenv.cfg").is_file(), venv
assert sys_prefix == venv, (sys_prefix, venv)
assert executable.is_relative_to(venv), (executable, venv)
assert module.is_relative_to(root / "src"), (module, root / "src")
assert editable, direct
assert source == root, (source, root)
report = {"root":str(root),"venv":str(venv),"sys_prefix":str(sys_prefix),"executable":str(executable),"module":str(module),"direct_url":url,"direct_url_source":str(source),"editable":editable}
report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
direct_url_path.write_text(raw + "\n", encoding="utf-8")
PY
    git -C "$worktree" check-ignore -v .venv/pyvenv.cfg > "$EVIDENCE_DIR/$label.git-check-ignore.txt"
    test -s "$EVIDENCE_DIR/$label.git-check-ignore.txt"
  )
}

run_host() {
  local label="$1"
  local worktree="$2"
  (
    cd "$worktree"
    if uv run --no-sync --locked --group dev --extra plugins python scripts/unittest_gate.py --suite host --output-dir "$EVIDENCE_DIR/$label-host-gate" > "$EVIDENCE_DIR/$label-host-gate.stdout.log" 2>&1; then rc=0; else rc=$?; fi
    printf '%s\n' "$rc" > "$EVIDENCE_DIR/$label-host-gate.exit-code"
    cat "$EVIDENCE_DIR/$label-host-gate.stdout.log"
    test "$rc" -eq 0
  )
}

cd "$A_PATH"
unset UV_PROJECT_ENVIRONMENT
uv python install
uv sync --locked --group dev --extra plugins
capture_env a-before "$A_PATH"
run_host a-before "$A_PATH"

cd "$B_PATH"
unset UV_PROJECT_ENVIRONMENT
uv python install
uv sync --locked --group dev --extra plugins
capture_env b "$B_PATH"
run_host b "$B_PATH"

cd "$A_PATH"
unset UV_PROJECT_ENVIRONMENT
# 关键：返回 A 后只允许 --no-sync；不得执行 uv sync 或普通 uv run。
capture_env a-return "$A_PATH"
run_host a-return "$A_PATH"
uv run --no-sync --locked --group dev --extra plugins python - "$EVIDENCE_DIR" <<'PY'
import json, pathlib, sys
evidence = pathlib.Path(sys.argv[1])
a = json.loads((evidence / "a-before.json").read_text(encoding="utf-8"))
b = json.loads((evidence / "b.json").read_text(encoding="utf-8"))
a2 = json.loads((evidence / "a-return.json").read_text(encoding="utf-8"))
for key in ("root", "venv", "sys_prefix", "executable", "module", "direct_url", "direct_url_source"): assert a[key] != b[key], (key, a[key], b[key])
assert a2 == a, (a, a2)
assert (evidence / "a-before.direct_url.json").read_bytes() == (evidence / "a-return.direct_url.json").read_bytes()
assert (evidence / "a-before.git-check-ignore.txt").read_text() == (evidence / "a-return.git-check-ignore.txt").read_text()
print("A/B/A isolation PASS; A return used --no-sync")
PY
printf 'A→B→A evidence retained at: %s\n' "$EVIDENCE_DIR"
