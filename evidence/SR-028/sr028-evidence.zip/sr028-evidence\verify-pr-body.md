## 目的

SR-028 AC-028-07 的**独立堆叠路径验证 PR**（含 AC-028-08 成功/负例/恢复时序）。本 PR 不合并。

- 主实施 PR：[#99](https://github.com/odango-chan/ca-agent-next/pull/99)
- 实施 Issue：[#96](https://github.com/odango-chan/ca-agent-next/issues/96)
- 本 PR base：`feature/issue-96-sr-028-uv-toolchain`（已包含 SR-028 的 uv 迁移、`scripts/unittest_gate.py` 与两个 Workflow）
- base SHA（创建时）：`83d23e8c04b1c05eb304c2a24a3392f6459ed0f1`
- 本 PR head：`verify/issue-96-sr-028-paths-trigger`
- head 相对 base 的累积 diff 必须且只能是 `.github/workflows/review-context.yml`

## 时序计划

1. commit `c1d7286`：在本文件加路径验证注释（opened 事件，成功路径）。
2. 第二个 commit：修改同一注释 → `pull_request.synchronize`，核验同一 Head SHA 下 Review Context Job 与 Ubuntu 3.12 / Windows 3.14.6 两个非 skipped SR-003 Job。
3. 第三个 commit：仅在临时 Workflow 中把生成器 `--base` 注入全零 SHA，并记录 `generator_base_sha=0000...`、`failure_injection=invalid-base`（受控负例）。
4. 第四个 commit：恢复 `--base "$BASE_SHA"` / `failure_injection=none`（恢复路径）。
5. 取证后关闭本 PR（未合并）。

## 约束

- 不修改 head 版 `Agent.md` 的 `review_scope`（保持唯一有效）。
- 不合并本 PR；不修改 `main`、设计分支或治理分支。
