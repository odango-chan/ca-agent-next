"""AC-028-01~03 证据采集：项目元数据、uv/解释器固定与依赖分组。

从仓库根执行：uv run --no-sync --locked --group dev --extra plugins python <this> <evidence_dir>
"""

from __future__ import annotations

import importlib.metadata as metadata
import json
import pathlib
import subprocess
import sys
import tomllib

evidence_dir = pathlib.Path(sys.argv[1]).resolve()
evidence_dir.mkdir(parents=True, exist_ok=True)
root = pathlib.Path.cwd()

pyproject_text = (root / "pyproject.toml").read_text(encoding="utf-8")
pyproject = tomllib.loads(pyproject_text)
dist = metadata.distribution("ca-agent-next")
project = pyproject["project"]
build = pyproject["build-system"]
tool_uv = pyproject.get("tool", {}).get("uv", {})
groups = pyproject.get("dependency-groups", {})
extras = project.get("optional-dependencies", {})
setuptools_find = (
    pyproject.get("tool", {}).get("setuptools", {}).get("packages", {}).get("find", {})
)

requires = list(dist.requires or [])
checks = {
    "distribution_name": dist.metadata["Name"],
    "distribution_version": dist.version,
    "requires_python_metadata": dist.metadata["Requires-Python"],
    "requires_dist": requires,
    "project_name": project["name"],
    "project_version": project["version"],
    "project_requires_python": project["requires-python"],
    "project_dependencies": project["dependencies"],
    "build_backend": build["build-backend"],
    "build_requires": build["requires"],
    "plugins_extra": extras.get("plugins"),
    "dev_group": groups.get("dev"),
    "uv_required_version": tool_uv.get("required-version"),
    "setuptools_find": setuptools_find,
    "pyyaml_in_runtime_requires_dist": any(
        "pyyaml" in item.lower() for item in requires
    ),
    "pyyaml_in_project_dependencies": any(
        "pyyaml" in item.lower() for item in project["dependencies"]
    ),
}
assert checks["distribution_name"] == "ca-agent-next", checks
assert checks["distribution_version"] == "0.1.0", checks
assert checks["requires_python_metadata"] == ">=3.11", checks
assert checks["build_backend"] == "setuptools.build_meta", checks
assert checks["project_dependencies"] == [], checks
assert checks["plugins_extra"] == [
    "ruamel.yaml>=0.18,<0.19",
    "jsonschema>=4.23,<5",
], checks
assert checks["dev_group"] == ["PyYAML>=6.0,<7"], checks
assert checks["uv_required_version"] == "==0.13.10", checks
assert checks["setuptools_find"] == {"where": ["src"], "include": ["ca_agent_next*"]}, checks
assert not checks["pyyaml_in_runtime_requires_dist"], checks
assert not checks["pyyaml_in_project_dependencies"], checks

# Requires-Dist 只允许来自 plugins extra 的两个依赖（带 extra 标记）
for item in requires:
    assert "pyyaml" not in item.lower(), item
    assert "extra ==" in item.lower(), item

py_version_file = root / ".python-version"
worktree_text = py_version_file.read_text(encoding="utf-8")
worktree_bytes = py_version_file.read_bytes()
assert worktree_text.strip() == "3.14.6", worktree_text

blob = subprocess.run(
    ["git", "cat-file", "-p", "HEAD:.python-version"],
    cwd=str(root),
    capture_output=True,
    check=True,
).stdout
assert blob == b"3.14.6\n", blob

uv_version = subprocess.run(
    ["uv", "--version"], capture_output=True, text=True, check=True
).stdout.strip()
python_version = subprocess.run(
    [sys.executable, "--version"], capture_output=True, text=True, check=True
).stdout.strip()
sys_prefix = sys.prefix

workflow_uv = {}
for workflow in (
    ".github/workflows/sr003-plugin-ci.yml",
    ".github/workflows/review-context.yml",
):
    text = (root / workflow).read_text(encoding="utf-8")
    pinned = "astral-sh/setup-uv@1db35dd8eee11c5894872e0b383ae6c406cf738d" in text
    version_pin = "version: '0.13.10'" in text or 'version: "0.13.10"' in text
    workflow_uv[workflow] = {"setup_uv_pinned_commit": pinned, "uv_version_pinned": version_pin}
    assert pinned and version_pin, (workflow, pinned, version_pin)

report = {
    "checks": checks,
    "python_version_file": {
        "worktree_text_repr": repr(worktree_text),
        "worktree_bytes_hex": worktree_bytes.hex(),
        "git_blob_sha": subprocess.run(
            ["git", "rev-parse", "HEAD:.python-version"],
            cwd=str(root),
            capture_output=True,
            text=True,
            check=True,
        ).stdout.strip(),
        "git_blob_content_repr": repr(blob.decode("utf-8")),
    },
    "uv_version": uv_version,
    "python_version": python_version,
    "sys_prefix": sys_prefix,
    "workflow_uv": workflow_uv,
    "tested_sha": subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=str(root), capture_output=True, text=True, check=True
    ).stdout.strip(),
}
(evidence_dir / "ac-028-01-03.json").write_text(
    json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
)
print(json.dumps(report, ensure_ascii=False, indent=2))
