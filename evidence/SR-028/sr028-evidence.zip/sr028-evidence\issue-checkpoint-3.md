## SR-028 实施检查点（批次 3 / 全量产品证据）

**时间**：2026-11-27（Asia/Shanghai）
**实施分支**：`feature/issue-96-sr-028-uv-toolchain` @ `83d23e8c04b1c05eb304c2a24a3392f6459ed0f1`（远端已核对一致）
**实施 PR**：[#99](https://github.com/odango-chan/ca-agent-next/pull/99)（OPEN，base `docs/issue-12-draft-design-review-20261126` @ `93f1389e7c5968cd30e8a74137207094864ecca0`）
**堆叠验证 PR**：[#100](https://github.com/odango-chan/ca-agent-next/pull/100)（已取证并关闭，**未合并**）

### 1. 固定基线复核（本轮结束时）

- PR #46：OPEN、未合并，head 仍为 `93f1389e7c5968cd30e8a74137207094864ecca0`，与固定设计快照一致。
- PR #97：OPEN、未合并，仅治理状态回填，未作为实施基线。
- 实施分支从固定 SHA 派生；`main` 未被修改（远端 `main` 仍为 `b2ed5eb84114f9c2556a0cd06ed974887b1b70ad`）。
- 三个实施 commit：
  - `f9e310b` pyproject dev group / uv pin / `.python-version` / `uv.lock`
  - `0c333f3` `scripts/unittest_gate.py` + 两个 Workflow 迁移
  - `83d23e8` 当前入口文档刷新（AC-028-10）

### 2. 修改文件清单（相对固定设计 SHA `93f1389`）

`.github/workflows/review-context.yml`、`.github/workflows/sr003-plugin-ci.yml`、`.python-version`（新增）、`Agent.md`、`README.md`、`docs/SR/SR-002-*.md`、`docs/SR/SR-003-*.md`、`docs/SR/SR-028-*.md`、`docs/设计说明书/G02-*/Python工程工具链设计说明书.md`、`docs/验收与实施/演示验收基线.md`、`pyproject.toml`、`scripts/unittest_gate.py`（新增）、`uv.lock`（新增）。无 `src/**`、`tests/**` 行为修改，无运行时依赖变更。

### 3. AC-028-01～10 状态（真实产品证据）

| AC | 状态 | 关键证据 |
|---|---|---|
| AC-028-01 | PASS | distribution `ca-agent-next` 0.1.0、`Requires-Python >=3.11`、`setuptools.build_meta`、src discovery、运行时 dependencies=[]；`Requires-Dist` 仅 plugins extra 两项且不含 PyYAML。证据：`sr028-evidence/ac-028-01-03/ac-028-01-03.json` |
| AC-028-02 | PASS | `.python-version` Git blob = `3.14.6\n`（blob `3f0a10f`）；uv `0.13.10`；setup-uv 固定 commit `1db35dd8eee11c5894872e0b383ae6c406cf738d` + `version: '0.13.10'`；`uv run --no-sync --locked --group dev --extra plugins python --version` = `Python 3.14.6` |
| AC-028-03 | PASS | `[dependency-groups].dev=["PyYAML>=6.0,<7"]`；PyYAML 不在运行时 metadata；plugins extra 保留 `ruamel.yaml>=0.18,<0.19`、`jsonschema>=4.23,<5` |
| AC-028-04 | PASS | 干净临时 worktree：正例 `uv sync --locked` exit 0、`uv lock --check` exit 0；仅将唯一 `PyYAML>=6.0,<7`→`<8` 后两条负例 exit 1 且匹配 `lockfile ... needs to be updated`；每次负例后 `git diff HEAD -- uv.lock` 与 status 均为空；恢复后两文件 clean；块 exit 0（cleanup 保留原码）。证据：`sr028-evidence/ac-028-04/` |
| AC-028-05 | PASS | A→B→A 两 detached worktree：a-before/b/a-return JSON 各含 root、venv、sys.prefix、executable、module、原始 direct_url、direct_url_source、editable=true；A/B 七字段全不同；A-return 与 A-before 逐字一致；direct_url.json 与 `git check-ignore -v` 输出逐字节一致；三次 Host gate 均 52/52、exit 0；返回 A 仅用 `uv run --no-sync --locked`；块 exit 0。证据：`sr028-evidence/ac-028-05/` |
| AC-028-06 | PASS | `go.mod` go directive `1.24`；Go `go1.26.6`（>=1.24）；`GOWORK=off`、GOOS=windows、`bin/echo-plugin.exe` 构建 exit 0；CWD 前后均为仓库根；四范围 gate：host 52/52、plugin 87/87、review-context 80/80、total 219/219，skipped/failures/errors/loader_errors=0、discovery_exception=null、整体 exit 0；Smoke exit 0、stderr 空、stdout 为基线固定单行 JSON。证据：`sr028-evidence/ac-028-06/` |
| AC-028-07 | PASS | 主 PR Run：[SR-003 #45955482682](https://github.com/odango-chan/ca-agent-next/actions/runs/45955482682)（ubuntu 3.12 + windows 3.14.6 均 success、非 skipped，四范围 gate 各 219/219、exit 0）；独立堆叠 PR #100 的 synchronize：同一 head `fa6d7be` 下 [Review Context #45956150601](https://github.com/odango-chan/ca-agent-next/actions/runs/45956150601) success + [SR-003 #45956150500](https://github.com/odango-chan/ca-agent-next/actions/runs/45956150500) 两个矩阵 Job success。Windows Job 精确断言 `Python 3.14.6`；Go 由 `setup-go@v5` + `go-version-file` 安装（CI 实测 go1.24.13）。paths 枚举完整保留 12 类路径。证据：`sr028-evidence/ci-main-pr-final/`、`sr028-evidence/stacked-verify/` |
| AC-028-08 | PASS | 成功路径（主 PR #99 head `83d23e8`）：Run #45955482683 success，诊断 Artifact `review-context-diagnostics-pr-99-45955482683-1` 与正式 Artifact `review-context-pr-99-45955482683-1` 分离；正式 Artifact 恰含 `review-scope.json`、`评审上下文.md`、`统一评审提示词.md`；gate 80/80 exit 0；`generator_base_sha=<真实 base>`、`failure_injection=none`。受控负例（堆叠 PR #100 head `4fccd38`，Run #45956888727 failure）：gate PASS 80/80，生成器实际执行 exit 3，stderr 含 `base 提交对象不可读取`，manifest 三文件均 MISSING，诊断 Artifact 存在、正式 Artifact 不存在；两个 invalid review_scope 单测 `test_validation_failure_writes_no_artifact`、`test_subprocess_returns_non_zero_with_location` 在 gate 日志中 ok。恢复路径（head `069c59d`，Run #45957598111 success）：`generator_base_sha=<真实 base>`、`failure_injection=none`，两个 Artifact 重新生成且正式 Artifact 恰为三文件 |
| AC-028-09 | PASS | 未修改其他仓库/`main`/设计分支/治理分支；无运行时依赖、setuptools backend、公开 API 变更；无新增签名/hash/Trust Registry/第二套依赖锁；改动文件清单见 §2 |
| AC-028-10 | PASS | README/Agent.md 增加当前安装、四范围 gate、Smoke、Go Echo 前置与 review-context 入口；SR-002/SR-003/演示基线新增明确标记的 SR-028 迁移后 uv 复验入口，原 pip 命令、受测 SHA、历史 PASS/CI 记录保持原文；G02/SR-028 增加实施状态与当前复验入口，AC 定义未改 |

### 4. 第七轮两个 P2 关闭证据

**P2-1（负例 PR 来源）**：负例 PR #100 base = `feature/issue-96-sr-028-uv-toolchain` @ `83d23e8c04b1c05eb304c2a24a3392f6459ed0f1`（已包含 SR-028 Workflow 迁移与 `scripts/unittest_gate.py`）；head = `verify/issue-96-sr-028-paths-trigger` @ `4fccd389d560a3e42d8672012eb5e1450c48e2f0`；head 相对 base 累积 diff 文件清单**仅** `.github/workflows/review-context.yml`（GitHub PR files API：+5/-2）。PR 已关闭、`mergedAt=null`。存档：`sr028-evidence/stacked-verify/pr100-negative-view.json`。

**P2-2（run-context 证据列）**：负例诊断 Artifact `review-context-diagnostics-pr-100-45956888727-1/run-context.txt` 逐项核验：
- `base_sha=83d23e8c04b1c05eb304c2a24a3392f6459ed0f1`（真实 PR base）
- `generator_base_sha=0000000000000000000000000000000000000000`（注入值）
- `failure_injection=invalid-base`
同时核验 `generator.exit-code=3`、stderr 含预期文本、manifest 三文件 MISSING、正式 Artifact 不存在；仅凭 stderr 不作 PASS 判定。

### 5. 本地证据归档位置

`C:\Users\<local-user>\Documents\ConnectionAgent\sr028-evidence\`（`ac-028-01-03/`、`ac-028-04/`、`ac-028-05/`、`ac-028-06/`、`ci-main-pr/`、`ci-main-pr-final/`、`stacked-verify/`、`local/`）。

### 6. 剩余问题与下一步

- 未单独为 paths 枚举中 `tests/**`、`src/**`、`examples/echo/**`、`.gitignore`、`scripts/review_context.py` 分别构造单文件触发 PR；本次由主 PR 累积 diff（pyproject/uv.lock/.python-version/scripts/unittest_gate.py/docs/SR-003/workflow）与堆叠 PR 的单文件 `review-context.yml` 触发实证覆盖，枚举本身完整保留。
- Windows Job 在 GitHub Runner 上耗时约 5 分钟（正常范围）。
- 实施 PR #99 保持 OPEN，未合并；SR-028 状态拟按全部产品 AC 证据提出 VERIFIED，等最终报告与评审确认。
