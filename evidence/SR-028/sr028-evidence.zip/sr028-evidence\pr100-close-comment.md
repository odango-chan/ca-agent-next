﻿## 堆叠验证结论（取证后关闭，未合并）

- base：`feature/issue-96-sr-028-uv-toolchain` @ `83d23e8c04b1c05eb304c2a24a3392f6459ed0f1`（已包含 SR-028 uv 迁移、scripts/unittest_gate.py 与两个 Workflow）
- head：`verify/issue-96-sr-028-paths-trigger` @ `069c59da351fede69e8b620967efca2a7a83b1e2`
- head 相对 base 累积 diff：仅 `.github/workflows/review-context.yml`

| 事件 / commit | Head SHA | Review Context Run | SR-003 Run | 结论 |
|---|---|---|---|---|
| opened `c1d7286` | c1d7286 | [45955998910](https://github.com/odango-chan/ca-agent-next/actions/runs/45955998910) success | [45955998821](https://github.com/odango-chan/ca-agent-next/actions/runs/45955998821) success | paths 触发成立 |
| synchronize `fa6d7be` | fa6d7be | [45956150601](https://github.com/odango-chan/ca-agent-next/actions/runs/45956150601) success | [45956150500](https://github.com/odango-chan/ca-agent-next/actions/runs/45956150500) success（ubuntu 3.12 + windows 3.14.6 均非 skipped） | AC-028-07 synchronize 证据 |
| synchronize `4fccd38`（受控负例） | 4fccd38 | [45956888727](https://github.com/odango-chan/ca-agent-next/actions/runs/45956888727) **failure（预期）** | [45956888769](https://github.com/odango-chan/ca-agent-next/actions/runs/45956888769) success | AC-028-08 负例 |
| synchronize `069c59d`（恢复） | 069c59d | [45957598111](https://github.com/odango-chan/ca-agent-next/actions/runs/45957598111) success | [45957598133](https://github.com/odango-chan/ca-agent-next/actions/runs/45957598133) success | AC-028-08 恢复 |

负例诊断 Artifact `review-context-diagnostics-pr-100-45956888727-1`：`run-context.txt` 记录 `base_sha=83d23e8…`、`generator_base_sha=0000000000000000000000000000000000000000`、`failure_injection=invalid-base`；`generator.exit-code=3`；stderr 含 `base 提交对象不可读取`；manifest 三份正式文件均 `MISSING`；gate PASS（80/80，skipped=0）；正式 Artifact 不存在。

恢复后成功 Run 同时产生诊断 Artifact 与正式 Artifact，正式 Artifact 解包恰为 `review-scope.json`、`评审上下文.md`、`统一评审提示词.md` 三份文件。

本 PR 未合并，现关闭。
