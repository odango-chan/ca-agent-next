set -euo pipefail
ROOT="$(pwd -P)"
EVIDENCE_DIR="$(mktemp -d "${TMPDIR:-/tmp}/sr028-lock-evidence.XXXXXX")"
WORKTREE_PARENT="$(mktemp -d "${TMPDIR:-/tmp}/sr028-lock-worktree.XXXXXX")"
LOCK_PATH="$WORKTREE_PARENT/lock-drift"
LOCK_ADDED=0
cleanup() {
  local original_rc=$?
  local cleanup_rc=0
  local cmd_rc=0
  trap - EXIT
  set +e
  cd "$ROOT"
  cmd_rc=$?
  if [ "$cmd_rc" -ne 0 ] && [ "$cleanup_rc" -eq 0 ]; then cleanup_rc=$cmd_rc; fi
  if [ "$LOCK_ADDED" -eq 1 ]; then
    git -C "$ROOT" worktree remove --force "$LOCK_PATH"
    cmd_rc=$?
    if [ "$cmd_rc" -ne 0 ] && [ "$cleanup_rc" -eq 0 ]; then cleanup_rc=$cmd_rc; fi
  fi
  rmdir "$WORKTREE_PARENT"
  cmd_rc=$?
  if [ "$cmd_rc" -ne 0 ] && [ "$cleanup_rc" -eq 0 ]; then cleanup_rc=$cmd_rc; fi
  printf 'SR028_LOCK_EVIDENCE_DIR=%s\n' "$EVIDENCE_DIR"
  if [ "$original_rc" -ne 0 ]; then exit "$original_rc"; fi
  if [ "$cleanup_rc" -ne 0 ]; then exit "$cleanup_rc"; fi
}
trap cleanup EXIT
git worktree add --detach "$LOCK_PATH" HEAD
LOCK_ADDED=1
cd "$LOCK_PATH"
unset UV_PROJECT_ENVIRONMENT
uv python install
if uv sync --locked --group dev --extra plugins > "$EVIDENCE_DIR/positive-sync.log" 2>&1; then
  printf '0\n' > "$EVIDENCE_DIR/positive-sync.exit-code"
else
  rc=$?
  printf '%s\n' "$rc" > "$EVIDENCE_DIR/positive-sync.exit-code"
  cat "$EVIDENCE_DIR/positive-sync.log"
  exit "$rc"
fi
if uv lock --check > "$EVIDENCE_DIR/positive-lock-check.log" 2>&1; then
  printf '0\n' > "$EVIDENCE_DIR/positive-lock-check.exit-code"
else
  rc=$?
  printf '%s\n' "$rc" > "$EVIDENCE_DIR/positive-lock-check.exit-code"
  cat "$EVIDENCE_DIR/positive-lock-check.log"
  exit "$rc"
fi
uv run --no-sync --locked --group dev --extra plugins python -c 'from pathlib import Path; p=Path("pyproject.toml"); s=p.read_text(encoding="utf-8"); old="PyYAML>=6.0,<7"; assert s.count(old)==1, "expected exactly one PyYAML constraint"; p.write_text(s.replace(old,"PyYAML>=6.0,<8",1), encoding="utf-8")'
git diff -- pyproject.toml > "$EVIDENCE_DIR/pyproject-drift.diff"
if uv lock --check > "$EVIDENCE_DIR/negative-lock-check.log" 2>&1; then
  echo 'FAIL: uv lock --check unexpectedly accepted a stale lockfile' >&2
  exit 1
else
  lock_check_rc=$?
fi
printf '%s\n' "$lock_check_rc" > "$EVIDENCE_DIR/negative-lock-check.exit-code"
test "$lock_check_rc" -ne 0
grep -Eiq 'lockfile.*needs to be updated' "$EVIDENCE_DIR/negative-lock-check.log"
git diff --exit-code HEAD -- uv.lock
test -z "$(git status --porcelain -- uv.lock)"
if uv sync --locked --group dev --extra plugins > "$EVIDENCE_DIR/negative-sync-locked.log" 2>&1; then
  echo 'FAIL: uv sync --locked unexpectedly accepted a stale lockfile' >&2
  exit 1
else
  sync_locked_rc=$?
fi
printf '%s\n' "$sync_locked_rc" > "$EVIDENCE_DIR/negative-sync-locked.exit-code"
test "$sync_locked_rc" -ne 0
grep -Eiq 'lockfile.*needs to be updated' "$EVIDENCE_DIR/negative-sync-locked.log"
git diff --exit-code HEAD -- uv.lock
test -z "$(git status --porcelain -- uv.lock)"
git restore --source=HEAD --worktree -- pyproject.toml
git diff --exit-code HEAD -- pyproject.toml uv.lock
test -z "$(git status --porcelain -- pyproject.toml uv.lock)"
printf 'Lock-drift evidence retained at: %s\n' "$EVIDENCE_DIR"
