## 实施范围

SR-028 Python 工程工具链与 uv 环境管理，实施 Issue #96。

- 上游需求：IR-007
- SR：SR-028 v0.2.9（固定设计快照 `93f1389e7c5968cd30e8a74137207094864ecca0`）
- 设计：G02 v0.2.7（同上固定快照）
- 独立设计评审：PR #46 Review #6084094037（`APPROVE_FOR_READY`，0 P0 / 0 P1 / 2 P2）
- 固定 Base：`3c7c48383c52504a4861900bc1f8b731442f16c2`
- 实施分支：`feature/issue-96-sr-028-uv-toolchain`
- 初始 base：`docs/issue-12-draft-design-review-20261126`
- 堆叠验证 PR：#100（已取证后关闭，**未合并**）

## Commit 与远端 SHA

| Commit | 内容 |
|---|---|
| `f9e310b` | pyproject dev dependency group、uv 0.13.10 pin、`.python-version` 3.14.6、`uv.lock` |
| `0c333f3` | `scripts/unittest_gate.py`、双平台 SR-003 CI 迁移、Review Context Workflow 迁移 |
| `83d23e8` | README/Agent/SR-002/SR-003/演示基线/G02/SR-028 当前 uv 入口刷新（AC-028-10） |

远端分支 SHA 已核对：`83d23e8c04b1c05eb304c2a24a3392f6459ed0f1`。

## 产品证据摘要

### 本地

- `uv lock --check` / `uv sync --locked --group dev --extra plugins` 退出 0；解释器 Python 3.14.6、uv 0.13.10。
- 四范围 gate：host 52 / plugin 87 / review-context 80 / total 219，failures/errors/skipped/loader_errors=0，`discovery_exception=null`，整体 exit 0。
- Host Smoke exit 0，stderr 为空。
- AC-028-04 锁漂移：正例 2 条 exit 0；负例 `uv lock --check` 与 `uv sync --locked` 均 exit 1 且匹配 `lockfile ... needs to be updated`；每次负例后 `uv.lock` 无 tracked diff/status；恢复后 clean。
- AC-028-05 A→B→A：两个 worktree 独立 `.venv`，A/B 的 root/venv/sys.prefix/executable/module/direct_url/source 全不同；A-return 与 A-before 逐字一致；返回 A 仅 `--no-sync --locked`；三次 Host gate 52/52 exit 0。
- AC-028-06：Go directive `1.24`、实测 `go1.26.6`、`GOWORK=off`、GOOS=windows、`bin/echo-plugin.exe` 构建成功、CWD 恢复。

### CI（真实 Run）

| Run | Head SHA | 结果 |
|---|---|---|
| [SR-003 #45955482682](https://github.com/odango-chan/ca-agent-next/actions/runs/45955482682) | `83d23e8` | ubuntu 3.12 + windows 3.14.6 均 success，四范围 gate 219/219 exit 0 |
| [Review Context #45955482683](https://github.com/odango-chan/ca-agent-next/actions/runs/45955482683) | `83d23e8` | success，两个分离 Artifact，正式 Artifact 恰为三文件 |
| [Review Context #45956150601](https://github.com/odango-chan/ca-agent-next/actions/runs/45956150601) / [SR-003 #45956150500](https://github.com/odango-chan/ca-agent-next/actions/runs/45956150500) | `fa6d7be`（堆叠 PR synchronize） | 同一 Head SHA 下 Review Context success + 两个矩阵 Job 非 skipped success |
| [Review Context #45956888727](https://github.com/odango-chan/ca-agent-next/actions/runs/45956888727) | `4fccd38`（受控负例） | failure（预期）：gate PASS 80/80、生成器 exit 3、stderr 含 `base 提交对象不可读取`、manifest 三文件 MISSING、仅诊断 Artifact |
| [Review Context #45957598111](https://github.com/odango-chan/ca-agent-next/actions/runs/45957598111) | `069c59d`（恢复） | success，`failure_injection=none`，诊断 + 正式 Artifact 重新生成 |

## AC 状态

| AC | 状态 |
|---|---|
| AC-028-01～03 | PASS |
| AC-028-04～05 | PASS |
| AC-028-06 | PASS |
| AC-028-07 | PASS（堆叠 PR 证据完整；paths 枚举完整保留） |
| AC-028-08 | PASS（成功 / 受控负例 / 恢复三路径） |
| AC-028-09～10 | PASS |

第七轮 P2-1 / P2-2 已在 Issue #96 检查点评论（`issuecomment-7212463039`）逐项关闭。

## 约束

- 不合并 PR #46、PR #97 或本 PR；不修改 `main`。
- 不修改设计分支与治理分支；不引入第二套依赖管理机制。
- 历史 pip 命令、受测 SHA 与既有 VERIFIED 证据只读保留。

## 证据归档

本地证据目录：`C:\Users\<local-user>\Documents\ConnectionAgent\sr028-evidence\`；逐 AC 证据与 P2 关闭明细见 Issue #96 检查点评论。
